"""Commodity price analysis: regression, classification and clustering."""
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.metrics import (mean_absolute_error, mean_squared_error, r2_score,
                             accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix, roc_curve,
                             ConfusionMatrixDisplay, silhouette_score)

# Paths are relative to the repo root, so the script runs from anywhere
ROOT = Path(__file__).resolve().parent.parent
FILE = ROOT / "data" / "commodity_prices.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

# Use a non-interactive backend if there is no display (e.g. servers/CI)
SHOW = True
if not matplotlib.get_backend().lower().startswith(("qt", "tk", "macosx", "module")):
    SHOW = False


def show():
    if SHOW:
        plt.show()
    plt.close()


df = pd.read_csv(FILE)
df.columns = ["State", "District", "Market", "Commodity", "Variety", "Grade",
              "Arrival_Date", "Min_Price", "Max_Price", "Modal_Price"]
df = df.drop_duplicates().dropna()
df = df[(df.Min_Price > 0) & (df.Max_Price >= df.Min_Price)]
df = df[df.Max_Price < df.Max_Price.quantile(0.99)]
df = df[df.Modal_Price < df.Modal_Price.quantile(0.99)]
df["Price_Range"] = df.Max_Price - df.Min_Price

for col in ["State", "Commodity", "Grade"]:
    df[col + "_enc"] = LabelEncoder().fit_transform(df[col])

print("Clean data shape:", df.shape)
print(df[["Min_Price", "Max_Price", "Modal_Price"]].describe().round(1), "\n")

# ---------------------------------------------------------------- 1. Regression
X = df[["Min_Price", "Max_Price", "State_enc", "Commodity_enc", "Grade_enc"]]
y = df["Modal_Price"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)

lr = LinearRegression().fit(Xtr, ytr)
pred = lr.predict(Xte)
mse = mean_squared_error(yte, pred)
print("=== 1. Multiple Linear Regression ===")
print(f"MAE  : {mean_absolute_error(yte, pred):.2f}")
print(f"MSE  : {mse:.2f}")
print(f"RMSE : {np.sqrt(mse):.2f}")
print(f"R2   : {r2_score(yte, pred):.4f}\n")

plt.figure(figsize=(5, 5))
plt.scatter(yte, pred, s=5, alpha=.4)
plt.plot([yte.min(), yte.max()], [yte.min(), yte.max()], "r--")
plt.xlabel("Actual Modal Price"); plt.ylabel("Predicted"); plt.title("Linear Regression")
plt.tight_layout(); plt.savefig(OUT / "1_linear_regression.png", dpi=120); show()

# ------------------------------------------------------------- 2-4. Classification
df["High_Price"] = (df.Modal_Price > df.Modal_Price.median()).astype(int)
Xc = df[["State_enc", "Commodity_enc", "Grade_enc", "Price_Range"]]
yc = df["High_Price"]
Xtr, Xte, ytr, yte = train_test_split(Xc, yc, test_size=0.2, random_state=42, stratify=yc)
sc = StandardScaler().fit(Xtr)
Xtr_s, Xte_s = sc.transform(Xtr), sc.transform(Xte)

roc_data = {}


def evaluate(name, model, Xa, Xb):
    model.fit(Xa, ytr)
    p = model.predict(Xb)
    prob = model.predict_proba(Xb)[:, 1]
    print(f"=== {name} ===")
    print(f"Accuracy : {accuracy_score(yte, p):.4f}")
    print(f"Precision: {precision_score(yte, p):.4f}")
    print(f"Recall   : {recall_score(yte, p):.4f}")
    print(f"F1 Score : {f1_score(yte, p):.4f}")
    print(f"AUC      : {roc_auc_score(yte, prob):.4f}")
    print("Confusion Matrix:\n", confusion_matrix(yte, p), "\n")
    roc_data[name] = (roc_curve(yte, prob), roc_auc_score(yte, prob))
    ConfusionMatrixDisplay.from_predictions(yte, p, display_labels=["Low", "High"], cmap="Blues")
    plt.title(name); plt.tight_layout()
    plt.savefig(OUT / (name.split(".")[0] + "_confusion_matrix.png"), dpi=120); show()
    return model


evaluate("2. Logistic Regression", LogisticRegression(max_iter=1000), Xtr_s, Xte_s)

dt = evaluate("3. Decision Tree", DecisionTreeClassifier(max_depth=6, random_state=42), Xtr, Xte)
print("Feature importance:", dict(zip(Xc.columns, dt.feature_importances_.round(3))), "\n")

plt.figure(figsize=(18, 8))
plot_tree(dt, max_depth=3, feature_names=list(Xc.columns), class_names=["Low", "High"],
          filled=True, fontsize=8)
plt.title("Decision Tree (top 3 levels)"); plt.tight_layout()
plt.savefig(OUT / "3_decision_tree.png", dpi=120); show()

evaluate("4. K-Nearest Neighbours (k=7)", KNeighborsClassifier(n_neighbors=7), Xtr_s, Xte_s)

plt.figure(figsize=(6, 5))
for name, ((fpr, tpr, _), auc) in roc_data.items():
    plt.plot(fpr, tpr, label=f"{name[3:]} (AUC={auc:.2f})")
plt.plot([0, 1], [0, 1], "k--"); plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
plt.title("ROC Curves"); plt.legend(); plt.tight_layout()
plt.savefig(OUT / "ROC_curves.png", dpi=120); show()

# ------------------------------------------------------------------ 5. Clustering
comm = df.groupby("Commodity").agg(Avg_Modal=("Modal_Price", "mean"),
                                   Avg_Range=("Price_Range", "mean")).reset_index()
Z = StandardScaler().fit_transform(np.log1p(comm[["Avg_Modal", "Avg_Range"]]))

inertia, sil = [], []
ks = range(2, 9)
for k in ks:
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(Z)
    inertia.append(km.inertia_); sil.append(silhouette_score(Z, km.labels_))
best_k = list(ks)[int(np.argmax(sil))]
print("=== 5. K-Means ===")
print("Silhouette scores:", dict(zip(ks, np.round(sil, 3))), "-> best k =", best_k)

km = KMeans(n_clusters=best_k, n_init=10, random_state=42).fit(Z)
comm["Cluster"] = km.labels_
print(comm.groupby("Cluster")[["Avg_Modal", "Avg_Range"]].agg(["mean", "count"]).round(1))
for c in range(best_k):
    print(f"Cluster {c} examples:", ", ".join(comm[comm.Cluster == c].Commodity.head(6)))

fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ax[0].plot(list(ks), inertia, "o-"); ax[0].set_title("Elbow method"); ax[0].set_xlabel("k")
ax[1].scatter(Z[:, 0], Z[:, 1], c=km.labels_, cmap="viridis", s=20)
ax[1].set_title(f"K-Means (k={best_k})"); ax[1].set_xlabel("log avg modal price (scaled)")
ax[1].set_ylabel("log avg price range (scaled)")
plt.tight_layout(); plt.savefig(OUT / "5_kmeans.png", dpi=120); show()
