# Commodity Price Analysis (Machine Learning)

Applies classic machine learning models to daily commodity prices from Indian
agricultural markets (mandis).

## Dataset
`data/commodity_prices.csv` – State, District, Market, Commodity, Variety, Grade,
Arrival Date, Min / Max / Modal price (₹ per quintal).

## Models
| # | Task | Model |
|---|------|-------|
| 1 | Regression (predict Modal Price) | Multiple Linear Regression |
| 2 | Classification (High vs Low price) | Logistic Regression |
| 3 | Classification | Decision Tree (max_depth=6) |
| 4 | Classification | K-Nearest Neighbours (k=7) |
| 5 | Clustering of commodities | K-Means (k chosen by silhouette score) |

Preprocessing: drop duplicates/missing values, remove invalid prices, trim the top
1% outliers, label-encode State/Commodity/Grade, scale features for LR and KNN.

## Project structure
```
commodity-price-ml/
├── data/commodity_prices.csv
├── src/main.py
├── outputs/          # generated plots
├── requirements.txt
└── README.md
```

## Run
```bash
pip install -r requirements.txt
python src/main.py
```
Metrics are printed to the console; plots (confusion matrices, ROC curves,
decision tree, K-Means) are saved to `outputs/`.

## Notes
- The regression uses Min and Max price as features, so it scores a very high R²
  by design; the classifiers use price range instead to avoid that leakage.
